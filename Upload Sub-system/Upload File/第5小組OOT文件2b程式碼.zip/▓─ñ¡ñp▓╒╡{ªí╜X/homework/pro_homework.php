<?php
    include_once '../public/web_function.php';
	include_once '../public/mem_check.php';
	$action = $_REQUEST["action"];
	switch ($action) {
		case "new"://新增


		// //上傳圖片
		// // XXX.jpg = echo $_FILES['myfile']['name'];
		// $uploadfile = $_FILES['myfile']['name'];

		// //移動照片到upload 資料夾裡面(因為已經在news資料夾裡面了 所以直接"upload/")
		// if (move_uploaded_file($_FILES['myfile']['tmp_name'], "upload/".iconv("utf-8", "big5", $uploadfile))) {
  //   		echo "Upload OK \n";
		// } else {
  //   		echo "Upload failed \n";
		// }

		// $NS_ID = $objDB->GetMaxID('NS_ID','news',7); //ID
		$NS_Title = quotes($_POST["NS_Title"]); //標題
		$NS_Message = quotes($_POST["NS_Message"]); //消息
		$NS_Status = quotes($_POST["NS_Status"]); //判斷是否發布
		$deadline = quotes($_POST["deadline"]);
		$id = $objDB->GetMaxID('id','my_hw',7);

		// //時間函數設定
		// date_default_timezone_set('Asia/Taipei');
		// $NS_Time = date("Y-m-d H:i:s");

		// //照片的名稱
		// $NS_pic = $uploadfile;


		//後來sibu教的
		// $sql = "select max(id) from my_hw"; //找最大
		// // //資料一筆一筆往下增加 , (客戶需求)
		// $rs = $objDB->Recordset($sql);
		// $row = $objDB->GetRows($rs);
		// 	if(strlen($row[0]["id"]) > 0) {
		// 		echo "!!!";
		// 		$id = $row[0]["id"]+1;
		// 	}
		// 	else {
		// 		echo "XXX";
		// 		$id = 1;
		// 	}

		$sql_insert = "insert into my_hw(id,name,content,deadline,NS_Status) values('$id','$NS_Title','$NS_Message','$deadline','$NS_Status')";
		$objDB->Execute($sql_insert);

		// ★★★★★★★★★★★★  一開始寫的2015.2.25  ★★★★★★★★★★★★
		// $sql = "insert into news(NS_ID,NS_Title,NS_Message,NS_Time,NS_Status,NS_pic,NS_order) values('$NS_ID','$NS_Title','$NS_Message','$NS_Time','$NS_Status','$NS_pic','$NS_order')";
		// $objDB->Execute($sql);


		// //每次新增一筆資料 就會配置一個 order id 給他們 然後更新資料庫
		// $sql = "SELECT * FROM news  order by NS_order ASC";
		// $rs = $objDB->Recordset($sql);
		// $row = $objDB->GetRows($rs);

		// for($i=0; $i<$objDB->RecordCount($rs); $i++)
		// {
		// 	$row[$i]["NS_order"]=$i+1;
		// 	$order = $row[$i]["NS_order"];
		// 	$ID = $row[$i]["NS_ID"];
		// 	$sql = "update news set NS_order='$order' where NS_ID='$ID'";
		// 	$objDB->Execute($sql);
		// }


?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script language="javascript">
alert('新增最新消息成功!');
location.href='homework.php';
</script>
<?php
		break;
		case "mdy"://修改

		//圖片
		$uploadfile = $_FILES['myfile']['name'];

		//移動照片到upload 資料夾裡面(因為已經在news資料夾裡面了 所以直接"upload/")
		if (move_uploaded_file($_FILES['myfile']['tmp_name'], "upload/".iconv("utf-8", "big5", $uploadfile)))
		{
    		echo "Upload OK \n";
		}
		else
		{
			//假設使用者沒有選照片(沒修改圖片) 我們就把原本那張照片傳過來
    		$uploadfile = $_POST["pic_hide"];
    		//echo $uploadfile;
		}

		$NS_ID = quotes(trim($_POST["NS_ID"]));
		$NS_Title = quotes($_POST["NS_Title"]);
		$NS_Message = $_POST["NS_Message"];
		$NS_pic = $uploadfile;

		//時間函數設定
		date_default_timezone_set('Asia/Taipei');
		$NS_Time = date("Y-m-d H:i:s");

		$NS_order = quotes($_POST["NS_order"]); //更改後順序
		$NS_Original_order = quotes($_POST["Original_order"]); //更改前順序

		if($NS_order > $NS_Original_order)//3改成5
		{
			$NS_Original_order += 1;
			//where NS_ID = '$NS_ID' = 找到那筆(3) 然後 update 、把 NS_order 設為 0
			$objDB->Execute("Update news set NS_pic='$NS_pic',NS_Title='$NS_Title',NS_Time='$NS_Time',NS_order = 0 where NS_ID = '$NS_ID'");
			//NS_order 在 $NS_Original_order and $NS_order (between 4and5)之間的 全部-1 然後update
			$objDB->Execute("Update news set NS_order=NS_order-1  where NS_order Between $NS_Original_order and $NS_order");

			$SQLquery ="SELECT Count(*) from news"; //去資料庫裏面看看有幾筆資料(可以貼到sql看)
			$RS = $objDB->Recordset($SQLquery);
			$RSArray = $objDB->GetRows($RS);
			$NewOrder = $RSArray[0][0]; //有幾筆

			if(($NS_order - $NewOrder) > 0) //100筆的時候 where NS_order = 0"是第3筆 資料庫裏面最大的筆數
				$objDB->Execute("Update news set NS_order = $NewOrder where NS_order = 0");
			else
				$objDB->Execute("Update news set NS_order = $NS_order where NS_order = 0");
		}
		else if($NS_order < $NS_Original_order)
		{
			$objDB->Execute("Update news set NS_pic='$NS_pic', NS_Title='$NS_Title',NS_Time='$NS_Time',NS_order = 0 where NS_ID = '$NS_ID'");
			$objDB->Execute("Update news set NS_order = NS_order+1 where NS_order Between $NS_order and $NS_Original_order");
			$objDB->Execute("Update news set NS_order = $NS_order where NS_order = 0 ");
		}
		else
		{
			$objDB->Execute("update news set NS_pic='$NS_pic', NS_Title='$NS_Title',NS_Time='$NS_Time' where NS_ID = '$NS_ID'");
		}




		// ★★★★★★★★ 2015.2.25 原本寫法 ★★★★★★★★★★★
		// //判斷資料庫裏面有沒有這個資料 並且作調整
		// $sql = "SELECT * FROM news  order by NS_order ASC";
		// $rs = $objDB->Recordset($sql);
		// $row = $objDB->GetRows($rs);

		// // 最大數量
		// $ALL_WORDS = $objDB->RecordCount($rs);

		// //更改值比原本值還大ex:2改成5
		// if($NS_order>$NS_Original_order)
		// {
		// 	//使用者輸入超過數量-> 我們安排成最大數
		// 	if($NS_order>$ALL_WORDS)
		// 		$NS_order = $ALL_WORDS;

		// 	for($i=$NS_Original_order; $i<$NS_order; $i++)
		// 	{
		// 		$row[$i]["NS_order"]=$row[$i]["NS_order"]-1;
		// 		$order = $row[$i]["NS_order"];
		// 		$ID = $row[$i]["NS_ID"];
		// 		$sql = "update news set NS_order='$order' where NS_ID='$ID'";
		// 		$objDB->Execute($sql);
		// 	}
		// }
		// else if($NS_order<$NS_Original_order)//更改值比原本值小
		// {
		// 	for($i=$NS_order-1; $i<$NS_Original_order; $i++)
		// 	{
		// 		$row[$i]["NS_order"]=$row[$i]["NS_order"]+1;
		// 		$order = $row[$i]["NS_order"];
		// 		$ID = $row[$i]["NS_ID"];
		// 		$sql = "update news set NS_order='$order' where NS_ID='$ID'";
		// 		$objDB->Execute($sql);
		// 	}
		// }
		// else//值沒變
		// {}

		// //寫入資料庫
		// $sql = "update news set NS_ID='$NS_ID', NS_Title='$NS_Title', NS_Message='$NS_Message', NS_pic='$NS_pic' , NS_order='$NS_order' where NS_ID='$NS_ID'";
		// 	$objDB->Execute($sql);

?>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script language="javascript">
alert('修改管理者成功!');
location.href='news.php';
</script>
	<?php
		break;
		case "del":
				$NS_ID = quotes(trim($_REQUEST["NS_ID"]));

				$sql = "delete from news where NS_ID ='$NS_ID'";
				$objDB->Execute($sql);

		//每次新增一筆資料 就會配置一個 order id 給他們 然後更新資料庫
		$sql = "SELECT * FROM news  order by NS_order ASC";
		$rs = $objDB->Recordset($sql);
		$row = $objDB->GetRows($rs);

		for($i=0; $i<$objDB->RecordCount($rs); $i++)
		{
			$row[$i]["NS_order"]=$i+1;
			$order = $row[$i]["NS_order"];
			$ID = $row[$i]["NS_ID"];
			$sql = "update news set NS_order='$order' where NS_ID='$ID'";
			$objDB->Execute($sql);
		}
	?>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<script language="javascript">
	alert('管理者資料資料刪除完畢!');
	location.href="news.php";
	</script>
	<?php
		break;

		case "delall":

		$ns_del = $_POST["ns_del"];
		foreach ($ns_del as $key=>$value) {
			// $ns_del 是array
			// $key 是0 1 2 3 4 5 6 7 8 9...
			// $value 是傳過來的ID
			// 意思應該是 ns_del[0]=XXX ,  ns_del[1]=XXX
			$id = $value;
			$sql = "delete from my_hw where id ='$id'";
			$objDB->Execute($sql);
		}

	?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<script language="javascript">
    alert('作業新增資料刪除完畢!');
    location.href="homework.php";
    </script>
<?php
		break;
	}
?>
