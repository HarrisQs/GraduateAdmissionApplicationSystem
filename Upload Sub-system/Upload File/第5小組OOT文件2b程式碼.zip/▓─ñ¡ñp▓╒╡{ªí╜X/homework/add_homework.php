<?php
    include("../public/mem_check.php");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $html_title;?>新增作業</title>
<script language="JavaScript" src="../js/common.js"></script>
<script language="javascript" src="../js/jquery.js" ></script>
<script type="text/javascript" src="../js/ui/minified/jquery.ui.core.min.js"></script>
<script type="text/javascript" src="../js/ui/minified/jquery.ui.datepicker.min.js"></script>
<script type="text/javascript" src="../js/ui/i18n/jquery.ui.datepicker-zh-TW.js"></script>

<script type="text/javascript">

 $(document).ready(function(){

    $(".date-pick" ).datepicker(
    { 
      dateFormat: 'yy-mm-dd', 
      showOn: "button",
      buttonImage: "../js/calendar.png",
      buttonImageOnly: true
    }
    );  

 	$("#mybtn").click(function(){

		 if($("#NS_Title").val()=='') {
					alert("請填入作業名稱");
					$("#NS_Title").focus();
					return false;
	    }else if($("#NS_Message").val()=='') {
					alert("請填入內容");
					$("#NS_Message").focus();
					return false;
		  }else if($("#NS_Title").val()=='刪掉我') {
          $('#NS_Title').val(""); //把剛剛填入的值刪調
      }
      else{
			  		$("form#form1").submit();
		}

	})

 })

</script>
<!-- 將css 的樣式套用過來 下面的class 就可以直接用 -->
<link href="../css/backend.css" rel="stylesheet" type="text/css" />
</head>

<body>
<table width="1000" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>
	<!-- header starting point -->
	<?php include("../include/header.php");?>
	<!-- header ending point -->    </td>
  </tr>
  <tr>
    <td valign="top"><table width="1000" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="160" valign="top" background="../images/bkline.jpg">
          	<!--menu starting point-->
            <?php include("../include/menu.php");?>
            <!--menu ending point-->
          </td>

          <td width="10" valign="top"><img src="../images/spacer.gif" width="1" height="1" /></td>
          <td width="830" valign="top"><table width="830" border="0" cellpadding="1" cellspacing="1">
            <tr>
              <td class="content">首頁 >網站系統設定 > 最新消息文章&gt; 新增</td>
            </tr>
            <tr>
              <td height="10" class="content_red_b"><img src="../images/spacer.gif" width="1" height="1" /></td>
            </tr>
            <tr>
              <td><span class="content_red_b">最新消息文章 - 新增</span></td>
            </tr>
            <tr>
              <td height="10"><br />
                <span class="form_title">
                <input name="search" type="button" class="content" id="search" value="回上一頁" onclick="history.back(-1)"/>
                </span>
              </td>
            </tr>
            <tr>
              <td>
              <!-- 管理員管理startinging  --> <!-- 這行是為了上船圖片用 enctype="multipart/form-data" -->
              <form name="form1" id="form1" method="post" enctype="multipart/form-data" action="pro_homework.php">
			        <input type="hidden" name="action" id="action" value="new">
              <table width="750" border="0">
                <tr>
                  <td width="190" align="right"  class="content">作業名稱：</td>
                  <td width="550">
                      <input name="NS_Title" type="text" class="form_fix" id="NS_Title" size="40"  style="width:250px"/>&nbsp;&nbsp;<img src="../js/ajax-loader.gif"  id="loading" style="margin-left:4px;display:none;" ><span id="checkid"></span> </td>
                </tr>
                <tr>
                  <td align="right" class="content">作業內容：</td>
                  <td>
                      <input name="NS_Message" type="text" class="form_fix" id="NS_Message" size="40" style="width:250px"/>
                  </td>
                </tr>

                <tr>
                  <td align="right" class="content">作業期限：</td>
                  <td>
                      <input name="deadline" type="text" class="txt date-pick" style="width:80px;"  readonly="readonly" value="<?php if(isset($_REQUEST["deadline"])&& $_REQUEST["deadline"] != "") echo $_REQUEST["deadline"]; ?>" />
                  </td>
                </tr>

                <tr>
                  <td width="190" align="right"  class="content">是否要發布消息：</td>
                  <td width="550">
                    <!-- radio 為html表單 只能選一個 -->
                    <INPUT type=radio name="NS_Status" value=Y>是
                    <INPUT type=radio name="NS_Status" value=N>否
                  </td>
                </tr>

                <!-- 上傳圖片檔案 -->
                <!-- <tr>
                  <td width="190" align="right"  class="content">上傳圖片：</td>
                  <td>
                    <input type="file" name="myfile">
                  </td>
                </tr> -->
                <!-- 結束上傳圖片 -->

                  <td align="right" class="content">&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>
                      <!-- type 是 reset 當你按下後重填後，填入的表單的東西就會消失 -->
                      <input name="resetbtn" type="reset" class="form_fix" id="resetbtn" value=" 重填 " />
                      <input name="mybtn" type="button" class="form_fix" id="mybtn"  value="確定送出"/>

                  </td>
                </tr>
              </table>
              </form>
              <!--管理員管理 ending-->
              </td>
            </tr>


          </table>
          </td>
        </tr>
    </table>
    </td>
  <tr>
    <td bgcolor="#999999"><img src="../images/spacer.gif" width="1" height="1" /></td>
  </tr>
  <tr>
    <td>
       <div class="copyright">
          <!--footer starting point-->
          <?php include("../include/footer.php");?>
          <!--footer starting point-->
       </div>
    </td>
  </tr>
</table>
</body>
</html>
