<?php
include_once '../public/web_function.php';
include_once '../public/mem_check.php';

//學生跟作業
$student = quotes($_GET["student"]);
$hw = quotes($_GET["hw"]);
$hw_id = quotes($_GET["hw_id"]);

// echo "<br>ST: ".$student;
// echo "<br>HW: ".$hw;
// echo "<br>HWID: ".$hw_id;
?>


<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8">
<title>上傳檔案</title>
</head>

<body>
<form name="form1" method="post" enctype="multipart/form-data" action="uphw.php">

<input name="hw" type="hidden" id="hw" value="<?php echo $hw ?>" />
<input name="student" type="hidden" id="student" value= "<?php echo $student ?> " />
<input name="hw_id" type="hidden" id="hw_id" value= "<?php echo $hw_id ?> " />

<p>選取要上傳的檔案...</p>
<p>
<input type="file" name="ufile">
</p>
<p>
<input type="submit" name="Submit" value="上傳">
<input name="Reset" type="reset" id="Reset" value="重設">
</p>
</form>

</body>

</html>