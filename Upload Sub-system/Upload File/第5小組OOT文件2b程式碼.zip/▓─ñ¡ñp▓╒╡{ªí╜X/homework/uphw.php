<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8">
<title>作業上傳結果</title>
</head>
<body>

<?php
include_once '../public/web_function.php';
include_once '../public/mem_check.php';
//接收傳遞過來的使用者名稱.作業
$student = $_POST["student"];
$hw = $_POST["hw"];
$hw_id = $_POST["hw_id"];
$student_id = $_SESSION['SUSHI_LOGIN_ID']; //學生id
//日期
date_default_timezone_set('Asia/Taipei');
$upload_date = date("Y-m-d");

// echo "<br>ST: ".$student;
// echo "<br>HW: ".$hw;
// echo "<br>HWID: ".$hw_id;
// echo "<br>STUD_ID: ".$student_id;

$error_msg=$_FILES["ufile"]["error"];
$fname=$_FILES["ufile"]["name"];
$tmpname=$_FILES["ufile"]["tmp_name"]; //路徑
$fsize=$_FILES["ufile"]["size"];
$ftype=$_FILES["ufile"]["type"];


//判定檔案是否傳遞成功
if($error_msg){
?>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<script language="javascript">
		alert('上傳失敗!');
		location.href="student_homework.php";
	</script>
<?php
} else {
	//檔案上傳成功
	// echo "已經收到上傳的檔案,檔名是 -> ".$fname."<br>";
	// echo "伺服器中暫存的位置和檔名 -> ".$tmpname."<br>";
	// echo "上傳檔案的大小 -> ".$fsize."<br>";
	// echo "上傳檔案的檔案類型 -> ".$ftype."<br>";

	//檔案名稱 = 學生id+作業名
	$uploadhw = $hw.$student_id.".txt";

	// echo "XXX"."$uploadhw";
	//將檔案另存到指定的位置
	// $success=copy($tmpname,$uploadhw);
	move_uploaded_file($_FILES["ufile"]["tmp_name"],"upload/".$uploadhw);


	// echo "檔案已經複製成功!<br>";
	// echo "新的路徑和檔名如下:<br>";
	// echo realpath($uploadhw)."<p>";
	//刪除暫存器中的檔案
	unlink($tmpname);

	$sql_insert = "insert into student_hw(student_id,hw_id,upload_day) values('$student_id','$hw_id','$upload_date')";
	$objDB->Execute($sql_insert);


	?>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<script language="javascript">
		alert('上傳成功囉!');
		location.href="student_homework.php";
	</script>

	<?php
}
?>

</body>
</html>