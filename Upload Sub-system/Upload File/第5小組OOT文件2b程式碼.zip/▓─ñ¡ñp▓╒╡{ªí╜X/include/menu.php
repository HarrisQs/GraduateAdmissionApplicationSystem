
<div id="menulist" class="arrowlistmenu">


	<div class="headerbar" id="menu-member">作業區</div>
	<ul>
    <!-- 老師出作業 -->
    <?php if( $_SESSION['SUSHI_LOGIN_ACCOUNT'] == "Teacher") { ?>
        <li><a href="../homework/homework.php">老師出作業</a></li>
    <?php } else { ?>
    <!-- 學生看作業 -->
    	<li><a href="../homework/student_homework.php"><?php echo $_SESSION['SUSHI_LOGIN_ACCOUNT']; ?> 的作業</a></li>
    <?php } ?>

    </ul>

    <?php if( $_SESSION['SUSHI_LOGIN_ACCOUNT'] == "Teacher") { ?>
        <div class="headerbar" id="menu-News">老師改分數</div>
        <ul>
            <li><a href="../score/score.php">下載作業跟批改</a></li>
        </ul>
    <?php } else { ?>
    <!-- 學生看作業 -->
        <div class="headerbar" id="menu-News">學生看分數</div>
        <ul>
            <li><a href="../score/student_score.php">分數</a></li>
        </ul>
    <?php } ?>

    

    <div class="headerbar" id="menu-News">操作說明</div>
    <ul>
        <li><a href="../Explanation.html">網頁使用說明</a></li>
    </ul>


    <!-- 老師可以新增學生帳號 -->
    <?php if( $_SESSION['SUSHI_LOGIN_ACCOUNT'] == "Teacher") { ?>
    <div class="headerbar" id="menu-News">學生帳密管理</div>
    <ul>
        <li><a href="../admin/admin.php">學生帳號密碼設定</a></li>
    </ul>
    <?php } ?>

</div>