<?php	
    if(!session_id())
	@session_start();

	if($_SESSION['SUSHI_LOGIN_ACCOUNT']=='')
	exit;
		
	header("Cache-Control: no-cache");
	
	include("../public/DBClass.php");
	include("../public/web_function.php");
    $objDB = new DBClass();
	
	$account =quotes(trim($_POST['AC_Account']));
	
	if($account!=''){
	$RS = $objDB->Recordset("SELECT * FROM admin WHERE account='$account'");
	$AllNum = $objDB->RecordCount($RS);
	 	if ($AllNum <> 0){
			//$myobj='{"obj": {"user":"yes"}}';
			$myobj = array(
			      'obj' => array('user'=>'yes')
			 );
	 	}else{
			//$myobj='{"obj": {"user":"no"}}';
			$myobj = array(
			      'obj' => array('user'=>'no')
			 );
		}
		echo json_encode($myobj);
	}
?>	