<?php	
	
	if(!session_id())
	@session_start();

	if(!in_array("MEMBER",$_SESSION['SUSHI_LOGIN_PERMIT']))
	exit;
		

	include("../public/DBClass.php");
	include("../public/web_function.php");
    $objDB = new DBClass();
	
	$CT_Account = quotes(trim($_POST['CT_Account']));
	
	if($CT_Account!=''){
	$RS = $objDB->Recordset("SELECT * FROM customer WHERE CT_Account='$CT_Account'");
	$AllNum = $objDB->RecordCount($RS);
	 	if ($AllNum <> 0){
			$myobj = array(
			      'obj' => array('user'=>'yes')
			 );
	 	}else{
			$myobj = array(
			      'obj' => array('user'=>'no')
			 );
		}
		echo json_encode($myobj);
	}
?>	