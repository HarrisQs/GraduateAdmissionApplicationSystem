<table width="950" height="50">
<tr>
            	<td width="17">&nbsp;</td>
   	<td width="754" valign="top">
<p class="footer_copyright">&nbsp;</p>              </td>
<td width="163" valign="top">
<p class="footer_copyright">
                  </p>                </td>
  </tr>
        </table>
