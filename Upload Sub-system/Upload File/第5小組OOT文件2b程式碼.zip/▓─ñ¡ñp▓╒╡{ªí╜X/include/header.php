<table width="1100" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td width="160" align="center" valign="middle"><img src="../images/logo.png" /></td>
    <td align="right"><br /></td>
    <td width="270" align="right"><table border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td rowspan="2" valign="bottom" class="login">
          登入者:<span style="color:#FF0000"> <?php echo $_SESSION['SUSHI_LOGIN_ACCOUNT'];?></span><span class="login_b">-<?php echo $_SESSION['SUSHI_LOGIN_NAME'];?></span>
        </td>
        <td width="10" rowspan="3"><img src="../images/spacer.gif" width="1" height="1" /></td>
        <td width="0" height="30"><img src="../images/spacer.gif" width="1" height="1" /></td>
      </tr>

      <tr>
        <td width="67">
          <a href="../public/logout.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image145','','../images/logout_r.gif',1)">
            <img src="../images/logout.gif" name="Image145" width="67" height="19" border="0" id="Image145" /></a>
          <a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('logout','','../images/logout_r.gif',1)"></a>
        </td>
      </tr>

      <tr>
        <td height="10"><img src="../images/spacer.gif" width="1" height="1" /></td>
        <td height="10"><img src="../images/spacer.gif" width="1" height="1" /></td>
      </tr>

</table>
</td>
    <td width="17"><img src="../images/spacer.gif" width="1" height="1" /></td>
  </tr>

      <tr>
        <td height="1" colspan="4" bgcolor="#B5B4B3"><img src="../images/spacer.gif" width="1" height="1" /><img src="../images/spacer.gif" width="1" height="1" /></td>
  </tr>
      <tr>
        <td height="2" colspan="4"><img src="../images/spacer.gif" width="1" height="1" /></td>
</tr>
</table>
