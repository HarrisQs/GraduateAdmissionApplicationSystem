<?php
//+++++++++++++各功能選項定義++++++++++++++++//

/* ==[ NEWS新聞發布區塊 news_list.php]== */
  $READ_NEWSNUM="10" ;  //新聞發布每頁分頁筆數

  $NEWS_THUMB_WIDTH_01 = 100; //新聞縮圖寬
  $NEWS_THUMB_HEIGHT_01 = 1000; //新聞縮圖高

  $FCK_InnerWidth = 600; //FCKeditor內頁圖片最大寬
  $FCK_InnerHeight = 1000; //FCKeditor內頁圖片最大高

/* ==[會員管理mem_list.php]== */
  $READ_MEMNUM="5" ;  //會員列表每頁分頁筆數
/* ==[消息管理new.php]== */
  $READ_NEWS="5";

/* ==[Domain]== */
 $EDM_HOST = "http://127.0.0.1/sushi/";
 $EDM_IMG    = "http://127.0.0.1/sushi/edm/";
 $EDM_PREVIMG    = "http://127.0.0.1/sushi/preview/";


//+++++++++++++++++++++++++++++++++++++++++//

//防止sql注入
function quotes($content){
	if (is_array($content)) {
		foreach ($content as $key=>$value) {
			$content[$key] = addslashes($value);
		}
	} else {
		$content = addslashes($content);
	}
	return $content;
}


//計算分頁function
// $ALL_PAGE所有分頁數目  $page_num頁數
function PageCount($ALL_PAGE,$page_num){
          for($i=1;$i<=$ALL_PAGE;$i++)  {
           $selected=($i==$page_num)?"selected":"";
           echo  "<option value=".$_SERVER['PHP_SELF']."?page_num=$i  $selected>第".$i."頁</option>";
             }
}

// $ALL_PAGE所有分頁數目  $page_num頁數 $NT_ID News使用
function PageCountSP($ALL_PAGE,$page_num,$ED_Type){
          for($i=1;$i<=$ALL_PAGE;$i++)  {
           $selected=($i==$page_num)?"selected":"";
           echo  "<option value=".$_SERVER['PHP_SELF']."?page_num=$i&ED_Type=$ED_Type  $selected>第".$i."頁</option>"; 
             }
}

// $ALL_PAGE所有分頁數目  $page_num頁數 $NT_ID   FAQ使用
function PageCountFAQ($ALL_PAGE,$page_num,$FAQA_CM_ID ){
          for($i=1;$i<=$ALL_PAGE;$i++)  {
           $selected=($i==$page_num)?"selected":"";
           echo  "<option value=".$_SERVER['PHP_SELF']."?page_num=$i&FAQA_CM_ID=$FAQA_CM_ID  $selected>第".$i."頁</option>"; 
             }
}


//產品列表設定使用
function PageCount2($ALL_PAGE,$page_num,$P_CM_ID){
          for($i=1;$i<=$ALL_PAGE;$i++)  {
           $selected=($i==$page_num)?"selected":"";
           echo  "<option value=".$_SERVER['PHP_SELF']."?page_num=$i&P_CM_ID=$P_CM_ID  $selected>第".$i."頁</option>"; 
             }
}

//產品搜尋列表設定使用
function PageCount3($ALL_PAGE,$page_num,$P_Event){
          for($i=1;$i<=$ALL_PAGE;$i++)  {
           $selected=($i==$page_num)?"selected":"";
           echo  "<option value=".$_SERVER['PHP_SELF']."?page_num=$i&P_Event=$P_Event  $selected>第".$i."頁</option>"; 
             }
}


function ckselect($str1,$str2) {
	if($str1==$str2) {
		return 'selected';
	}
	return '';
}

function ckRadio($str1,$str2) {
	if($str1==$str2) {
		return 'checked="checked"';
	}
	return '';
}

function ckbox($str1,$strarray) {
			if(in_array($str1,$strarray)) {
				return 'checked="checked"';
			}
			return '';
		 }


	if(!session_id())
	{
	  @session_start();
	}

?>