<?php
	include_once 'web_function.php';
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php

if (isset($_POST['userid']) && isset($_POST['password']))
{
  $userid = quotes(trim($_POST['userid']));
  $password = quotes(trim($_POST['password']));

  include_once 'DBClass.php';
  $objDB = new DBClass();


  $rs = $objDB->Recordset("select * from admin where account='$userid' and password='$password'");
  $row = $objDB->GetRows($rs);
  $AllNum = $objDB->RecordCount($rs);


	   if ($AllNum <> 0){

			$_SESSION['SUSHI_LOGIN_ID'] = $row[0]["AC_ID"]; //student_id
			$_SESSION['SUSHI_LOGIN_ACCOUNT'] = $row[0]["account"];


			$AC_ID = $row[0]["AC_ID"];

			$objDB->Execute("UPDATE admin SET AC_Lastlogin = now() where AC_ID='$AC_ID' "); 
?>
			    <script language=javascript>
					location.href="../welcome/main.php";
				</script>
<?php

	   }else{ ?>
		  <script language=javascript>
			 alert("帳號或密碼錯誤！");
			 history.go(-1);
		  </script>
	   <?php
	   }
   }else{?>
     <script language=javascript>
		 alert("未取的權限！");
		 window.location="index.php";
	 </script>
   <?php
   }
?>
