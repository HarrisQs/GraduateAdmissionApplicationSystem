<?
	if(!session_id()){
	  session_start();
	}

	$T=session_destroy();
    $_SESSION['SUSHI_LOGIN_ACCOUNT']="";   
?>

<script language="javascript">location.href='../index.php';</script>