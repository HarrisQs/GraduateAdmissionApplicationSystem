<?php
error_reporting(E_ALL ^ E_WARNING ^ E_NOTICE);
session_start();

/*
if (empty($_SESSION['Admin_Auth'])){

	?>
		<script language="javascript">		
		location.href='../index.php';
    location.href='http://user.sushi-express.com.tw/';
		</script>			
	<?

}
else {
  if (empty($_SESSION['Admin_Auth']['storage'])) {
	?>
		<script language="javascript">		
		location.href='../index.php';
    location.href='http://user.sushi-express.com.tw/';
		</script>			
	<?
  
  }
}
*/
include("DBClass.php");
$objDB = new DBClass();
$html_title="SUSHI EXPRESS ";
 //print_r ($_SESSION);

?>
