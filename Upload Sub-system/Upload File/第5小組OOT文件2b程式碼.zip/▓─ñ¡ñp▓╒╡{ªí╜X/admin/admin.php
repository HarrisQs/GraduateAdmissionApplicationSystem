<?php
include_once("../public/mem_check.php");
include_once("../public/web_function.php");


//下面是計算全部留言用的
$ALL_COUNT = $objDB->Recordset("SELECT * FROM admin  order by AC_ID desc");
$ALL_WORDS = $objDB->RecordCount($ALL_COUNT); //ALL_WORDS 計算出有幾筆資料

//分頁選單用的
$ALL_PAGE=ceil($ALL_WORDS/$READ_MEMNUM); //計算所需頁數

//判斷頁數為數字
if(is_numeric(quotes($_GET['page_num']))){
	 $page_num = quotes($_GET['page_num']);
}else{
     $page_num = 0;
}
?>

<!--定義網頁中 HTML 語法的版本-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<!--如果需要使用符合XML 規範的XHTML 文檔，則應該在文檔中的<html> 標籤中至少使用一個xmlns 屬性，以指定整個文檔所使用的主要命名空間-->
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<!--告訴網頁瀏覽器你的HTML網頁的文字碼是萬用字元碼"utf-8"。-->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 

<title><?php echo $html_title;?>管理者管理>列表</title>
<script src="../js/common.js" language="javascript"></script>
<script language="javascript" type="text/javascript" src="../js/jquery.js"></script>
<script type="text/JavaScript">
<!--
$(function() {

			$("#mybtn1").click(function(){

				 var mycount = 0;
				$("input[class='checkitem']").each(function() {
					if($(this).attr("checked")!=undefined){
						mycount = mycount+1;
					}
				});

				  if(mycount>0){
					$("form#frmGroupudp").submit();
				  }else{
				   alert("請勾選要刪除的管理者");
				  }
			 })

		 $("#checkAll").click(function() {

		   if($("#checkAll").attr("checked"))
			{
				$("input[class='checkitem']").each(function() {
				  $(this).attr("checked", true);
			  });
			}
			else
			{
			  	$("input[class='checkitem']").each(function() {
				  $(this).attr("checked", false);
			  });
		   }

		 });

});


//-->
</script>

<link href="../css/backend.css" rel="stylesheet" type="text/css" />
</head>

<body onload="MM_preloadImages('../images/logout_r.gif','../images/logout_r.gif')">
<table width="1000" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td><!-- header starting point -->
        <?php include("../include/header.php");?>
        <!-- header ending point -->
    </td>
  </tr>
  <tr>
    <td valign="top"><table width="1100" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="160" valign="top" background="../images/bkline.jpg">
        <!--menu starting point-->
        <?php include("../include/menu.php");?></td>
        <!--menu ending point-->
        <td width="10" valign="top"><img src="../images/spacer.gif" width="10" height="1" /></td>
        <td width="930" valign="top"><table width="830" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td height="30" class="content">首頁 &gt;網站系統設定 &gt; 使用者設定 &gt; 列表</td>
          </tr>
          <tr>
            <td height="10" class="content_red_b"><img src="../images/spacer.gif" width="1" height="1" /></td>
          </tr>
          <tr>
            <td><span class="content_red_b">使用者設定定 - 列表</span></td>
          </tr>
          <tr>
            <td height="10">&nbsp;</td>
          </tr>
          <tr>
            <td valign="top">

                <table width="825" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td>

			<?php
			   if(empty($page_num))$page_num=1;
				$start_num=$READ_MEMNUM*($page_num-1);
			?>
                        <table width="830" height="25" border="0" cellpadding="0" cellspacing="0">
                          <tr>
                            <td width="218" height="30">

                            <input name="button13" type="button" class="content" id="mybtn1" value="刪除已選擇" />
                            <input name="button3" type="button" class="content" id="button3" onclick="MM_goToURL('parent','add_admin.php');return document.MM_returnValue" value="新增管理者" />

                            </td>
                            <td width="607" class="content" align="right">前往頁面 　 第<?php echo $page_num;?>頁，共<?php echo $ALL_PAGE; ?> 頁 ( <span class="point_red" style="font-weight:bold"><?php echo $ALL_WORDS; ?></span> <span class="content">個管理者 ) 
                              <?php
						$back=$page_num-'1';
						$next=$page_num+'1';
						if(!($back<=0)){echo "<a href=".$_SERVER['PHP_SELF']."?page_num=$back>上一頁</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ";}
						if($next<=$ALL_PAGE){echo "<a href=".$_SERVER['PHP_SELF']."?page_num=$next>下一頁</a>";}
						?>

                              <select name="select" class="content" onchange="window.location.href=this.options[this.selectedIndex].value;">
                                  <?php  PageCount($ALL_PAGE,$page_num);  ?>
                                </select>            </td>
                          </tr>
                      </table></td>
                  </tr>
                  <tr>
                    <td><form name="frmGroupudp" id="frmGroupudp" method="post" action="admin_process.php">
                      <table width="820" height="55" border="0" cellpadding="1" cellspacing="1" bordercolor="#777777" bgcolor="#555555">
                        <tr>
                          <td width="25" height="22" align="center" bgcolor="#898989"><input type="checkbox" id="checkAll"/></td>
                          <td width="55" align="center" bgcolor="#898989" class="back_w"><a href="#">NO.</a></td>
                          <td width="152" align="center" bgcolor="#898989" class="back_w"><a href="#">管理者姓名</a></td>
                          <td bgcolor="#898989" align="center" class="back_w"><a href="#">管理者帳號</a></td>
                          <td bgcolor="#898989" align="center" class="back_w"><a href="#">身份</a></td>
                          <td width="150" align="center" bgcolor="#898989" class="back_w"><a href="#"></a><a href="#">上次登入日期</a></td>
                          <td bgcolor="#898989" align="center" class="sorttable_nosort enter_wb">管理</td>
                        </tr>
                        <?php
						$sql = "SELECT * FROM admin   order by AC_ID desc limit $start_num,$READ_MEMNUM";
						$rs = $objDB->Recordset($sql);
						$row = $objDB->GetRows($rs);
            $rr=$objDB->GetRows_Index($rs);
            echo $rr[0][0];

					 ?>
                        <?php for($i=0;$i<$objDB->RecordCount($rs);$i++){?>
                        <?php if($i%2==0){$bgcolor="#EBEBEB";}else{$bgcolor="#FFFFFF";}?>
                        <tr>
                          <td height="25" align="center" bgcolor="<?php echo $bgcolor;?>"  class="enter_wb">
                          <input type="checkbox" name="adm_del[]" value="<?php echo $row[$i]["AC_ID"];?>" class="checkitem" /></td>
                          <td bgcolor="<?php echo $bgcolor;?>" align="center"><?php echo $i+1;?></td>
                          <td bgcolor="<?php echo $bgcolor;?>" class="content" align="center"><?php echo $row[$i]["username"]; ?> </td>
                          <td width="167" bgcolor="<?php echo $bgcolor;?>" class="content" style="width:px;word-wrap:break-word;overflow:auto" align="center"><?php echo $row[$i]["account"]; ?></td>
                          <td bgcolor="<?php echo $bgcolor;?>" class="content" align="center"><?php if($row[$i]["job"]==1) echo "老師"; else echo "學生"; ?> </td>
                          <td align="center" bgcolor="<?php echo $bgcolor;?>" class="content"><span class="content" style="width:px;word-wrap:break-word;overflow:auto"><?php echo $row[$i]["AC_Lastlogin"]; ?></span></td>
                          <td width="123" align="center" bgcolor="<?php echo $bgcolor;?>">

                          <input name="button4" type="button" class="login" id="button4" value="刪除" onclick="if(confirm('確定要刪除此筆資料嗎?'))MM_goToURL('parent','admin_process.php?action=del&AC_ID=<?php echo $row[$i]["AC_ID"]; ?>');return document.MM_returnValue"/>
                          <input name="button2" type="button" class="login" id="button2" onclick="MM_goToURL('parent','md_admin.php?AC_ID=<?php echo $row[$i]["AC_ID"]; ?>');return document.MM_returnValue" value="修改" />

                          </td>
                        </tr>

                        <?php }?>
                        <?php if($objDB->RecordCount($rs)==0){?>
                        <div align="center" style="margin-top:5px">無管理者資料！</div>
                        <?php }?>
                      </table>
                      <input name="action" type="hidden" id="action" value="delall" />
                    </form></td>
                  </tr>
                  <tr>
                    <td><table width="830" border="0" cellspacing="0" cellpadding="0">

                    </table></td>
                  </tr>
                </table>
                </td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td bgcolor="#999999"><img src="../images/spacer.gif" width="1" height="1" /></td>
  </tr>
  <tr>
    <td class="copyright">
      <!--footer starting point-->
      <?php include("../include/footer.php");?>
      <!--footer starting point-->
    </td>
  </tr>
</table>
</body>
</html>
