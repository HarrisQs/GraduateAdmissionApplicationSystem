<?php
    include("../public/mem_check.php");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $html_title;?>管理者維護</title>
<script language="JavaScript" src="../js/common.js"></script>
<script language="javascript" src="../js/jquery.js" ></script>
<script>

 $(document).ready(function(){
 
		$("#AC_Account").blur(function(){
			if($("#AC_Account").val()!=''){
			$.ajax({
			type: "POST",
			dataType:'json',
			data: {AC_Account: $('#AC_Account').val()},
			url: '../include/ckAccount.php',
			beforeSend: function(XMLHttpRequest){
			  $("#checkid").html('');
			  $("#loading").show();
			  $("#mybtn").attr('disabled', true);
			},
			success:function(json, textStatus) {
						var exist = json.obj.user;
						 if(exist == "yes"){
							$("#checkid").html('<font color="#FF0000">此管理者帳號已存在請重新輸入</font>');
							$("#mybtn").attr('disabled', true);
						  }else{
							$("#checkid").html('<font color="#0033FF">此管理者帳號可以使用</font>');
							$("#mybtn").attr('disabled', false);
						  }
					},
			complete: function(XMLHttpRequest, textStatus){
			  $("#loading").hide();
			},
			error: function(xhr) {
			  alert('Ajax request 發生錯誤');
			}
		 	 });

		   }
		 });

 	$("#mybtn").click(function(){

		 if($("#AC_Account").val()=='') {
					alert("請填入帳號");
					$("#AC_Account").focus();
					return false;
	    }else if($("#AC_Pass").val()=='') {
					alert("請填入密碼");
					$("#AC_Pass").focus();
					return false;
	     }else if($("#AC_RePass").val()=='') {
					alert("請填入確認密碼");
					$("#AC_RePass").focus();
					return false;
	     }else if($("#AC_Pass").val()!=$("#AC_RePass").val()) {
					alert("確認密碼不相符");
					$("#AC_RePass").focus();
					return false;
		 }else if($("#AC_Name").val()=='') {
					alert("請填入名稱");
					$("#AC_Name").focus();
					return false;
		 }else{
			  		$("form#form1").submit();
		}
	})
  
 })

</script>
<link href="../css/backend.css" rel="stylesheet" type="text/css" />
</head>

<body>
<table width="1000" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>
	<!-- header starting point -->
	<?php include("../include/header.php");?>
	<!-- header ending point -->    </td>
  </tr>
  <tr>
    <td valign="top"><table width="1000" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="160" valign="top" background="../images/bkline.jpg">
          	<!--menu starting point-->
            <?php include("../include/menu.php");?>
            <!--menu ending point-->          </td>
            
          <td width="10" valign="top"><img src="../images/spacer.gif" width="1" height="1" /></td>
          <td width="830" valign="top"><table width="830" border="0" cellpadding="1" cellspacing="1">
            <tr>
              <td class="content">首頁 >網站系統設定 > 管理者管理&gt; 新增</td>
              </tr>
            <tr>
              <td height="10" class="content_red_b"><img src="../images/spacer.gif" width="1" height="1" /></td>
              </tr>
            <tr>
              <td><span class="content_red_b">管理者管理 - 新增</span></td>
              </tr>
            <tr>
              <td height="10"><br />
                <span class="form_title">
                <input name="search" type="button" class="content" id="search" value="回上一頁" onclick="history.back(-1)"/>
                </span></td>
              </tr>
            <tr>         
              <td>            
              
              <!--管理員管理startinging-->
              <form name="form1" id="form1" method="post" action="admin_process.php">
			  <input type="hidden" name="action" id="action" value="new">
              <table width="750" border="0">
                <tr>
                  <td width="190" align="right"  class="content">帳號：</td>
                  <td width="550">
                      <input name="AC_Account" type="text" class="form_fix" id="AC_Account" size="40"  style="width:250px"/>&nbsp;&nbsp;<img src="../js/ajax-loader.gif"  id="loading" style="margin-left:4px;display:none;" ><span id="checkid"></span> </td>
                  </tr>
                <tr>
                  <td align="right" class="content">密碼：</td>
                  <td>
                      <input name="AC_Pass" type="password" class="form_fix" id="AC_Pass" size="40" style="width:250px"/>                  </td>
                </tr>
                <tr>
                  <td align="right" class="content">確認密碼：</td>
                  <td>
                      <input name="AC_RePass" type="password" class="form_fix" id="AC_RePass" size="40" style="width:250px"/>                  </td>
                </tr>
                <tr>
                  <td align="right" class="content">學生名稱：</td>
                  <td>
                      <input name="AC_Name" type="text" class="form_fix" id="AC_Name"  size="40" style="width:250px"/>                  </td>
                </tr>
                <tr>
                  <td align="right" class="content">身份：</td>
                  <td>
                      <input type="radio" name="job" id="job" value="0"> 學生
                      <input type="radio" name="job" id="job" value="1"> 老師
                  </td>
                </tr>
                <tr>
                  <td align="right" valign="top" class="content"><br /></td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td align="right" class="content">&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>
                      <input name="resetbtn" type="reset" class="form_fix" id="resetbtn" value="  重填  " />
                      <input name="mybtn" type="button" class="form_fix" id="mybtn"  value="確定送出"/>                  </td>
                </tr>                
              </table>
              </form>
              <!--管理員管理 ending-->              </td>
            </tr>
            
            
          </table>         </td>
        </tr>
        
    </table></td>
  </tr>
  <tr>
    <td bgcolor="#999999"><img src="../images/spacer.gif" width="1" height="1" /></td>
  </tr>
  <tr>
    <td>
       <div class="copyright">
          <!--footer starting point-->
          <?php include("../include/footer.php");?>
          <!--footer starting point-->
       </div>   
    </td>
  </tr>
</table>
</body>
</html>
