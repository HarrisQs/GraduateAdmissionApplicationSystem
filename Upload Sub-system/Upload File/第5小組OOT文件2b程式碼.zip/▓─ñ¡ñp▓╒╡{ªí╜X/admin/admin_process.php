<?php
    include_once '../public/web_function.php';
	include_once '../public/mem_check.php';
	$action = $_REQUEST["action"];
	switch ($action) {
		case "new":

		$AC_ID = $objDB->GetMaxID('AC_ID','admin',7);
		$AC_Account = quotes($_POST["AC_Account"]);
		$AC_Pass = quotes($_POST["AC_Pass"]);
		$AC_Name = quotes($_POST["AC_Name"]);
		$job = quotes($_POST["job"]);
		$identify = quotes($_POST["identify"]);

		$sql = "insert into admin(AC_ID,account,password,username,job) values('$AC_ID','$AC_Account','$AC_Pass','$AC_Name','$job')";
		$objDB->Execute($sql);

?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script language="javascript">
alert('新增管理者成功!');
<?php if($identify!=1) {?>
location.href='admin.php';
<?php } else { ?>
	location.href='../index.php';
	<?php } ?>
</script>
<?php
		break;
		case "mdy":
		$AC_ID = quotes(trim($_POST["AC_ID"]));
		$AC_Name = quotes($_POST["AC_Name"]);
		$AC_Pass = quotes(trim($_POST["AC_Pass"]));


		if($AC_Pass!=''){
			$sql = "update admin set password='$AC_Pass',username='$AC_Name' where AC_ID='$AC_ID'";
		}else{
			$sql = "update admin set username='$AC_Name' where AC_ID='$AC_ID'";
		}
		$objDB->Execute($sql);
		?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script language="javascript">
alert('修改管理者成功!');
location.href='admin.php';
</script>
	<?php
		break;
		case "del":
				$AC_ID = quotes(trim($_REQUEST["AC_ID"]));

				$sql = "delete from admin where AC_ID ='$AC_ID'";
				$objDB->Execute($sql);
	?>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<script language="javascript">
	alert('管理者資料資料刪除完畢!');
	location.href="admin.php";
	</script>
	<?php
		break;

		case "delall":
		$adm_del = $_POST["adm_del"];
		foreach ($adm_del as $key=>$value) {
			$AC_ID = $value;
			$sql = "delete from admin where AC_ID ='$AC_ID'";
			$objDB->Execute($sql);
		}
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<script language="javascript">
    alert('管理者資料資料刪除完畢!');
    location.href="admin.php";
    </script>
<?php
		break;
	}
?>
