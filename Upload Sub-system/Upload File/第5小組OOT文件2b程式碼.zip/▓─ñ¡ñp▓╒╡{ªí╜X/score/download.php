<?php 
// header('Content-type:application/force-download');
// header('Content-type:application/force-download'); //告訴瀏覽器 為下載 
// header('Content-Transfer-Encoding: Binary'); //編碼方式
// header('Content-Disposition:attachment;filename=hello.txt'); //檔名
// echo 'Hello PHP';

include("../public/mem_check.php");
include_once("../public/web_function.php");

$hwname = quotes($_GET['hwname']);
$studentID = quotes($_GET['studentID']);

// 下載下來的檔名
$filename = $hwname.$studentID.".txt";
//路徑中的檔名
$myFile = "../homework/upload/".$hwname.$studentID.".txt";

$mm_type="application/octet-stream";

header("Cache-Control: public, must-revalidate");
header("Pragma: hack"); // WTF? oh well, it works...
header("Content-Type: " . $mm_type);
header("Content-Length: " .(string)(filesize($myFile)) );
header('Content-Disposition: attachment; filename="'.$filename.'"');
header("Content-Transfer-Encoding: binary\n");
readfile($myFile);

?>