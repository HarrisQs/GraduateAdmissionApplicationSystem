<?php
include_once("../public/mem_check.php");
include_once("../public/web_function.php");

$hw_id = quotes($_GET['hw_id']);

$sql = "select * from student_hw where hw_id='$hw_id'";
$rs = $objDB->Recordset($sql);
$row = $objDB->GetRows($rs);
$count = $objDB->Recordcount($rs);//數量
//分頁選單用的
$ALL_PAGE = ceil($count/$READ_NEWS); //計算所需頁數



$Myhomework_sql = "select * from my_hw where id = '$hw_id'";
$Myhomework_rs = $objDB->Recordset($Myhomework_sql);
$Myhomework_row = $objDB->GetRows($Myhomework_rs);


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>老師改作業分數</title>
<script src="../js/common.js" language="javascript"></script>
<script language="javascript" type="text/javascript" src="../js/jquery.js"></script>
<link href="../css/backend.css" rel="stylesheet" type="text/css" />
</head>

<body onload="MM_preloadImages('../images/logout_r.gif','../images/logout_r.gif')">

<!-- html 語法: tr是列 td是欄 -->
<table width="1000" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>
    	  <!-- header starting point -->
        <?php include("../include/header.php");?>
        <!-- header ending point -->
    </td>
  </tr>

  <tr>
    <td valign="top">
    <table width="1000" border="0" cellpadding="0" cellspacing="0">
      <tr>

        <td width="1" valign="top" background="../images/bkline.jpg">
        <!--menu starting point-->
        <?php include("../include/menu.php");?>
        <!--menu ending point-->
        </td>
        <td width="10" valign="top"><img src="../images/YZU_logo.gif" width="10" height="1" /></td>
        <td width="830" valign="top">
        <table width="943" border="0" cellpadding="0" cellspacing="0">

          <tr>
            <td height="30" colspan="2" class="content"> </td>
          </tr>

          <tr>
            <td  colspan="2" >
            <span class="content_red_b">老師改分數 - <?php echo $Myhomework_row[0]["name"];?> </span>
            </td>
      	  </tr>

      	  <tr>
            <td width="100" height="30"></td>

            <td width="831" align="right">

            <!-- 換頁功能 -->
            <?php
			         if(empty($page_num))$page_num=1;
				          $start_num=$READ_NEWS*($page_num-1);
			      ?>
            前往頁面 　 第<?php echo $page_num;?>頁，共<?php echo $ALL_PAGE; ?> 頁 ( <span class="point_red" style="font-weight:bold"><?php echo $count; ?></span> <span class="content">則 ) 

            <?php
						$back=$page_num-'1';
						$next=$page_num+'1';

            if(!($back<=0)){echo "<a href=".$_SERVER['PHP_SELF']."?page_num=$back&ED_Type=$ED_Type>上一頁</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ";}
						if($next<=$ALL_PAGE){echo "<a href=".$_SERVER['PHP_SELF']."?page_num=$next&ED_Type=$ED_Type>下一頁</a>";}

            ?>

            <select name="select" class="content" onchange="window.location.href=this.options[this.selectedIndex].value;">
                <?php  PageCountSP($ALL_PAGE,$page_num,1);  ?>
            </select>

            </td>
          </tr>

          <table width="930" height="25" border="0" cellpadding="0" cellspacing="0">
            <tr>
                <td>
                <form name="frmGroupudp" id="frmGroupudp" method="post" action="pro_homework.php">
                <table width="900" height="55" border="0" cellpadding="1" cellspacing="1" bordercolor="#777777" bgcolor="#555555">
                  <tr>
                    <td width="25" align="center" bgcolor="#898989" class="back_w">NO.</td>
                    <td width="100" align="center" bgcolor="#898989" class="back_w">繳交學生</td>
                    <td width="75" bgcolor="#898989" align="center" class="back_w">作業上傳日期</td>
                    <td width="50" align="center" bgcolor="#898989" class="back_w">下載學生作業</td>
                    <td width="50" align="center" bgcolor="#898989" class="back_w">批改分數</td>
                  </tr>

                    <!-- 一個for 迴圈去跑、印出資料庫裡面的東西 --> <!-- objDB->RecordCount($rs)用來算次數 -->
                    <?php for($i=0;$i<$objDB->RecordCount($rs);$i++){?>
                    <?php
                      if($i%2==0)
                        $bgcolor="#EBEBEB";
                      else
                         $bgcolor="#FFFFFF";

                    $stuid = $row[$i]["student_id"];
                	$sql_s = "select * from admin where AC_ID = '$stuid'";
                	$rs_s = $objDB->Recordset($sql_s);
					$row_s = $objDB->GetRows($rs_s);
                    ?>
                        <tr>
                          <td bgcolor="<?php echo $bgcolor;?>" align="center"><?php echo $i+1;?></td>
                          <td bgcolor="<?php echo $bgcolor;?>" align="center" class="content"><?php
							             echo $row_s[0]["username"];
                           ?> </td>
                          <td width="167" bgcolor="<?php echo $bgcolor;?>" class="content" style="width:px;word-wrap:break-word;overflow:auto" align="center"><?php echo $row[$i]["upload_day"]; ?></td>

                          <!-- 下載 -->
                          <td bgcolor="<?php echo $bgcolor;?>" align="center" class="content">
                            <a href="download.php?hwname=<?php echo $Myhomework_row['0']['name'];?>&studentID=<?php echo $row_s['0']['AC_ID'];?>">下載</a>
                          </td>

                          <td align="center" bgcolor="<?php echo $bgcolor;?>" class="content">
                          <?php
                            $scoreid = $row[$i]["id"];
                            $sql_checkscore = "select * from student_hw where id='$scoreid'";
                            $rs_checkscore = $objDB->Recordset($sql_checkscore);
                            $row_checkscore = $objDB->GetRows($rs_checkscore);
                            if($row_checkscore[0]["score"]!=0){
                              echo $row_checkscore[0]["score"];
                              ?> <a href="givenumber.php?score_hw_id=<?php echo $row[$i]["id"];?>&hw_id=<?php echo $hw_id; ?>" > | 修改分數</a> <?php 
                            } else {
                          ?>
                            <a href="givenumber.php?score_hw_id=<?php echo $row[$i]["id"];?>&hw_id=<?php echo $hw_id; ?>" >尚未批改</a>
                            <?php } ?>

                          </td>

                        </tr>
                        <?php }?>

                        <?php if($objDB->RecordCount($rs)==0){?>
                        <div align="center" style="margin-top:5px">目前尚無作業！</div>
                        <?php }?>
                      </table>
                      <input name="action" type="hidden" id="action" value="delall" />
                    </form></td>
                  </tr>
                  <tr>
                    <td><table width="830" border="0" cellspacing="0" cellpadding="0">
                    </table>
                  </td>
                </tr>

  </table>
</td>
</tr>
</table>
</body>
</html>
